<?php

return [
    'name' => 'RatingSystemPro'
];
