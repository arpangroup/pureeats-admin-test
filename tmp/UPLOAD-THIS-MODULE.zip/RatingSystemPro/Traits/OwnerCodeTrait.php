<?php


namespace Modules\RatingSystemPro\Traits;

trait OwnerCodeTrait
{

    /**
     * Run Owner Script
     * @return []
     */
    public static function runOwnerScript()
    {

    }


}
